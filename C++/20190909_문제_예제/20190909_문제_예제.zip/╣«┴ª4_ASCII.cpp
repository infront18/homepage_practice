#include <stdio.h>

int main()
{
	int ch1 = 'A';
	
	scanf("%d", &ch1);
	printf("%c", ch1);
	return 0;
}
