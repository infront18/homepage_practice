#include <stdio.h>

int main()
{
	char ch1 = 'A';
	
	scanf("%c", &ch1);
	printf("%d", ch1);
	return 0;
}
