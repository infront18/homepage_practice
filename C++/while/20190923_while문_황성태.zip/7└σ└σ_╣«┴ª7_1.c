#include <stdio.h>

int main()
{
	int num;
	int i = 0;
	
	printf("����� �Է��Ͻÿ�. \n");
	scanf("%d", &num);

	while (i<num)
	{
		printf("Hello world! \n");
		i++;
	}
	return 0;
}
