#include <stdio.h>

int main()
{
	char str[]={'G', 'o', 'o', 'd', ' ', 't', 'i', 'm', 'e'};

	for(int i=0; i<str[i]; i++)
	{
		printf("%c", str[i]);
	}
	return 0;
}
